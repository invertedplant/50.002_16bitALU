This is the 16-bit ALU for Group 14-5 for the 2020 50.002 course in ISTD. There is a quick guide in the attached pdf describing how the ALU works. Couple of things to note:

1. This is written in Lucid, not Verilog, for the Alchitry Io.
2. A couple of constraints were changed for easier writing of code.
3. There are comments left behind in the code for some elaboration beyond the .pdf, you don't have to read the pdf but it helps! 